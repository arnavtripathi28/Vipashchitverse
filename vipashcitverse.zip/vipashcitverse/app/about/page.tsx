export const metadata = {
  title: "मेरे बारे में | VipashcitVerse",
  description: "अरनव त्रिपाठी — भौतिकी का विद्यार्थी और शब्दों का यात्री।",
};

export default function AboutPage() {
  return (
    <div className="max-w-reading mx-auto px-6 py-16 sm:py-24 animate-fadeIn">
      <p className="text-xs font-sanshi uppercase tracking-widest text-maroon dark:text-maroon-light text-center">
        परिचय
      </p>
      <h1 className="mt-4 font-serifhi text-3xl sm:text-4xl text-center text-ink dark:text-cream">
        लेखक के बारे में
      </h1>

      <div className="mt-12 font-serifhi text-lg leading-loose text-ink/85 dark:text-cream/85 space-y-6">
        <p>मैं अरनव त्रिपाठी हूँ।</p>
        <p>भौतिकी का विद्यार्थी और शब्दों का यात्री।</p>
        <p>
          मेरे लिए कविता केवल भावों की अभिव्यक्ति नहीं, बल्कि उन चीज़ों को
          बचाकर रखने का एक तरीका है जिन्हें समय अक्सर हमसे छीन लेता है।
        </p>
        <p>VipashcitVerse मेरी रचनाओं का एक निजी साहित्यिक घर है।</p>
      </div>

      <div className="mt-14 pt-10 border-t hairline text-center">
        <p className="font-serifhi text-xl text-ink dark:text-cream">
          Arnav Tripathi
        </p>
        <p className="mt-1 text-sm font-sanshi text-ink/55 dark:text-cream/55">
          Poet · Writer · Student
        </p>
      </div>
    </div>
  );
}
