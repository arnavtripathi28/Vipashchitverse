import { Instagram, Twitter, Facebook } from "lucide-react";
import ContactForm from "@/components/ContactForm";

export const metadata = {
  title: "संपर्क | VipashcitVerse",
  description: "अरनव त्रिपाठी से संपर्क करें।",
};

export default function ContactPage() {
  return (
    <div className="max-w-reading mx-auto px-6 py-16 sm:py-24 animate-fadeIn">
      <h1 className="font-serifhi text-3xl text-center text-ink dark:text-cream">
        संपर्क
      </h1>
      <p className="mt-3 text-center text-sm font-sanshi text-ink/55 dark:text-cream/55">
        अपने विचार, प्रतिक्रिया या संदेश यहाँ भेजें।
      </p>

      <div className="mt-12">
        <ContactForm />
      </div>

      <div className="mt-14 pt-10 border-t hairline flex items-center justify-center gap-5">
        <a
          href="#"
          aria-label="Instagram"
          className="text-ink/50 dark:text-cream/50 hover:text-maroon dark:hover:text-maroon-light"
        >
          <Instagram size={18} />
        </a>
        <a
          href="#"
          aria-label="Twitter"
          className="text-ink/50 dark:text-cream/50 hover:text-maroon dark:hover:text-maroon-light"
        >
          <Twitter size={18} />
        </a>
        <a
          href="#"
          aria-label="Facebook"
          className="text-ink/50 dark:text-cream/50 hover:text-maroon dark:hover:text-maroon-light"
        >
          <Facebook size={18} />
        </a>
      </div>
    </div>
  );
}
