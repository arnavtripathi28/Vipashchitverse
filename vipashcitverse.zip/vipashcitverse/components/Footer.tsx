import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t hairline mt-24">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-12 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-8">
        <div>
          <p className="font-serifhi text-lg text-maroon dark:text-maroon-light">
            VIPASHCITVERSE
          </p>
          <p className="mt-2 font-serifhi text-sm text-ink/60 dark:text-cream/60 max-w-xs">
            जहाँ शब्द सिर्फ लिखे नहीं जाते, जिए जाते हैं।
          </p>
        </div>

        <nav className="flex flex-col gap-2 font-sanshi text-sm">
          <Link href="/kavita" className="text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light">कविताएँ</Link>
          <Link href="/gazal" className="text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light">ग़ज़ल</Link>
          <Link href="/shayari" className="text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light">शायरी</Link>
          <Link href="/about" className="text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light">मेरे बारे में</Link>
          <Link href="/contact" className="text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light">संपर्क</Link>
        </nav>
      </div>
      <div className="border-t hairline">
        <p className="max-w-6xl mx-auto px-5 sm:px-8 py-5 text-xs text-ink/45 dark:text-cream/45 font-sanshi">
          © 2026 Arnav Tripathi. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
