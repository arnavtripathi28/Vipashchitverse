import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "VipashcitVerse | Arnav Tripathi",
  description:
    "अरनव त्रिपाठी की कविताओं, ग़ज़लों, शायरी और साहित्यिक रचनाओं का व्यक्तिगत संग्रह।",
  openGraph: {
    title: "VipashcitVerse | Arnav Tripathi",
    description:
      "अरनव त्रिपाठी की कविताओं, ग़ज़लों, शायरी और साहित्यिक रचनाओं का व्यक्तिगत संग्रह।",
    type: "website",
    locale: "hi_IN",
    siteName: "VipashcitVerse",
  },
  twitter: {
    card: "summary_large_image",
    title: "VipashcitVerse | Arnav Tripathi",
    description:
      "अरनव त्रिपाठी की कविताओं, ग़ज़लों, शायरी और साहित्यिक रचनाओं का व्यक्तिगत संग्रह।",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="hi">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Serif+Devanagari:wght@400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen flex flex-col antialiased">
        <Header />
        <main className="flex-1 animate-unfold origin-top">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
