"use client";

import { useEffect, useState } from "react";
import { Share2, Copy, Bookmark, Check } from "lucide-react";
import { Poem } from "@/data/poems";

export default function PoemActions({ poem }: { poem: Poem }) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    try {
      const bookmarks = JSON.parse(
        window.localStorage.getItem("vv-bookmarks") || "[]"
      ) as string[];
      setSaved(bookmarks.includes(poem.slug));
    } catch {
      /* ignore */
    }
  }, [poem.slug]);

  function handleCopy() {
    navigator.clipboard?.writeText(`${poem.title}\n\n${poem.content}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  function handleShare() {
    const url = typeof window !== "undefined" ? window.location.href : "";
    if (navigator.share) {
      navigator.share({ title: poem.title, url }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(url);
    }
  }

  function handleBookmark() {
    try {
      const bookmarks = JSON.parse(
        window.localStorage.getItem("vv-bookmarks") || "[]"
      ) as string[];
      const next = saved
        ? bookmarks.filter((s) => s !== poem.slug)
        : [...bookmarks, poem.slug];
      window.localStorage.setItem("vv-bookmarks", JSON.stringify(next));
      setSaved(!saved);
    } catch {
      /* localStorage unavailable */
    }
  }

  const btn =
    "w-10 h-10 flex items-center justify-center rounded-full border hairline hover:bg-ink/5 dark:hover:bg-cream/10 transition-colors";

  return (
    <div className="flex items-center gap-3">
      <button onClick={handleShare} aria-label="साझा करें" className={btn}>
        <Share2 size={15} />
      </button>
      <button onClick={handleCopy} aria-label="कॉपी करें" className={btn}>
        {copied ? <Check size={15} /> : <Copy size={15} />}
      </button>
      <button
        onClick={handleBookmark}
        aria-label="बुकमार्क करें"
        className={btn}
      >
        <Bookmark size={15} fill={saved ? "currentColor" : "none"} />
      </button>
    </div>
  );
}
