import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./data/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        parchment: {
          DEFAULT: "#F4EEE1",
          light: "#FAF6EC",
          dark: "#EAE1CC",
        },
        ink: {
          DEFAULT: "#2A2420",
          soft: "#4A4038",
        },
        maroon: {
          DEFAULT: "#7A2E2E",
          light: "#9A4B42",
          dark: "#5C2020",
        },
        brown: {
          DEFAULT: "#6B4A32",
          light: "#8A6644",
        },
        nightpage: {
          DEFAULT: "#171310",
          soft: "#221C17",
          card: "#28221C",
        },
        cream: {
          DEFAULT: "#EFE6D8",
        },
      },
      fontFamily: {
        serifhi: ["'Noto Serif Devanagari'", "'Tiro Devanagari Hindi'", "serif"],
        sanshi: ["'Noto Sans Devanagari'", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        paper:
          "radial-gradient(circle at 1px 1px, rgba(42,36,32,0.05) 1px, transparent 0)",
      },
      backgroundSize: {
        paper: "18px 18px",
      },
      maxWidth: {
        reading: "42rem",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0", transform: "translateY(6px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        unfold: {
          "0%": { opacity: "0", transform: "scaleY(0.98)" },
          "100%": { opacity: "1", transform: "scaleY(1)" },
        },
      },
      animation: {
        fadeIn: "fadeIn 0.6s ease-out both",
        unfold: "unfold 0.5s ease-out both",
      },
    },
  },
  plugins: [],
};
export default config;
