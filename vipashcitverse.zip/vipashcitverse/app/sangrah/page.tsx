import { getAllPoems } from "@/data/poems";
import ArchiveClient from "@/components/ArchiveClient";

export const metadata = {
  title: "संग्रह | VipashcitVerse",
  description: "अरनव त्रिपाठी की सभी रचनाओं का पूर्ण संग्रह — खोजें, छाँटें और पढ़ें।",
};

export default function SangrahPage() {
  const poems = getAllPoems();
  return (
    <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 sm:py-20">
      <h1 className="font-serifhi text-3xl text-ink dark:text-cream mb-2">
        संग्रह
      </h1>
      <p className="text-sm font-sanshi text-ink/55 dark:text-cream/55 mb-10">
        सभी रचनाएँ, एक ही स्थान पर।
      </p>
      <ArchiveClient poems={poems} />
    </div>
  );
}
