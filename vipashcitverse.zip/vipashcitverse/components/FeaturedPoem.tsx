import Link from "next/link";
import { Poem, formatHindiDate } from "@/data/poems";
import PoemActions from "./PoemActions";

export default function FeaturedPoem({ poem }: { poem: Poem }) {
  return (
    <section className="max-w-3xl mx-auto px-5 sm:px-8 py-16 sm:py-24 animate-fadeIn">
      <p className="text-center text-xs font-sanshi tracking-widest uppercase text-maroon dark:text-maroon-light">
        चुनिंदा रचना
      </p>
      <h2 className="mt-4 text-center font-serifhi text-2xl sm:text-3xl text-ink dark:text-cream">
        {poem.title}
      </h2>
      <p className="mt-2 text-center text-xs font-sanshi text-ink/50 dark:text-cream/50">
        {poem.category} · {formatHindiDate(poem.date)} · {poem.author}
      </p>

      <div className="poem-text mt-10 text-ink/90 dark:text-cream/90 text-center px-4">
        {poem.content.split("\n").slice(0, 8).join("\n")}
      </div>

      <div className="mt-10 flex items-center justify-center gap-6">
        <PoemActions poem={poem} />
      </div>

      <div className="mt-8 text-center">
        <Link
          href={`/poem/${poem.slug}`}
          className="text-sm font-sanshi text-maroon dark:text-maroon-light underline underline-offset-4"
        >
          पूरी कविता पढ़ें →
        </Link>
      </div>
    </section>
  );
}
