export function cn(...classes: Array<string | false | undefined | null>) {
  return classes.filter(Boolean).join(" ");
}

/**
 * Placeholder for a future database layer.
 *
 * Today, poem data lives in `data/poems.ts` as a local in-memory array so the
 * site can ship without any backend. When you're ready to move to a real
 * database (Supabase, Firebase, etc.), implement this interface against that
 * service and swap the import in the pages below from `data/poems` to this
 * module — no component or page needs to change its shape, since both
 * expose the same functions (getAllPoems, getPoemBySlug, ...).
 */
export type { Poem, Category } from "@/data/poems";
