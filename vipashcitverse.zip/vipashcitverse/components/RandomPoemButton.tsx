"use client";

import { useRouter } from "next/navigation";
import { Shuffle } from "lucide-react";
import { getRandomPoem } from "@/data/poems";

export default function RandomPoemButton({ className = "" }: { className?: string }) {
  const router = useRouter();

  return (
    <button
      onClick={() => router.push(`/poem/${getRandomPoem().slug}`)}
      className={`inline-flex items-center gap-2 text-sm font-sanshi border hairline rounded-full px-4 py-2 hover:bg-ink/5 dark:hover:bg-cream/10 transition-colors ${className}`}
    >
      <Shuffle size={14} />
      कोई भी एक कविता
    </button>
  );
}
