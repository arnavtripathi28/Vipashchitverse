import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Poem, formatHindiDate } from "@/data/poems";

export default function PoemCard({ poem }: { poem: Poem }) {
  return (
    <Link
      href={`/poem/${poem.slug}`}
      className="group block paper-card p-6 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300"
    >
      <p className="text-xs font-sanshi tracking-wide uppercase text-maroon dark:text-maroon-light">
        {poem.category}
      </p>
      <h3 className="mt-3 font-serifhi text-xl leading-snug text-ink dark:text-cream">
        {poem.title}
      </h3>
      <p className="mt-3 font-serifhi text-sm text-ink/65 dark:text-cream/65 leading-relaxed line-clamp-2">
        {poem.excerpt}
      </p>
      <div className="mt-5 flex items-center justify-between text-xs font-sanshi text-ink/45 dark:text-cream/45">
        <span>
          {formatHindiDate(poem.date)} · {poem.readingTime}
        </span>
        <span className="flex items-center gap-1 text-maroon dark:text-maroon-light group-hover:gap-2 transition-all">
          पढ़ें <ArrowRight size={13} />
        </span>
      </div>
    </Link>
  );
}
