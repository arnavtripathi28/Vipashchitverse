import { getPoemsByCategory } from "@/data/poems";
import ArchiveClient from "@/components/ArchiveClient";

export const metadata = {
  title: "ग़ज़ल | VipashcitVerse",
  description: "अरनव त्रिपाठी की ग़ज़लों का संग्रह।",
};

export default function GazalPage() {
  const poems = getPoemsByCategory("ग़ज़ल");
  return (
    <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 sm:py-20">
      <h1 className="font-serifhi text-3xl text-ink dark:text-cream mb-2">
        ग़ज़ल
      </h1>
      <p className="text-sm font-sanshi text-ink/55 dark:text-cream/55 mb-10">
        शेरों में गुँथी हुई गहराई।
      </p>
      <ArchiveClient poems={poems} lockedCategory="ग़ज़ल" />
    </div>
  );
}
