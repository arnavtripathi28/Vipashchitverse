// ─────────────────────────────────────────────────────────────────────────
// VipashcitVerse — केंद्रीय काव्य डेटा (Central Poetry Data Store)
// ─────────────────────────────────────────────────────────────────────────
// यहाँ मौजूद सभी कविताएँ "SAMPLE CONTENT" हैं — केवल डिज़ाइन और लेआउट दिखाने
// के लिए रखी गई हैं। ये अरनव त्रिपाठी की वास्तविक रचनाएँ नहीं हैं।
// All poems in this file are PLACEHOLDER / SAMPLE CONTENT ONLY.
// They are NOT the real writings of Arnav Tripathi — replace them with the
// author's actual poems before publishing.
//
// नई कविता जोड़ने के लिए, बस नीचे दिए गए ऐरे में एक नया ऑब्जेक्ट जोड़ें।
// To add a new poem, simply push a new object into the `poems` array below.
// इसके लिए UI कोड में कोई बदलाव करने की ज़रूरत नहीं है।
// ─────────────────────────────────────────────────────────────────────────

export type Category =
  | "कविता"
  | "ग़ज़ल"
  | "शायरी"
  | "मुक्तक"
  | "प्रेम"
  | "विरह"
  | "समाज"
  | "जीवन"
  | "आत्मसंवाद";

export interface Poem {
  id: string;
  title: string;
  slug: string;
  category: Category;
  date: string; // ISO format: YYYY-MM-DD
  excerpt: string;
  content: string; // line breaks preserved with \n — never auto-justified
  tags: string[];
  featured?: boolean;
  readingTime: string; // e.g. "2 मिनट"
  author?: string;
}

export const CATEGORIES: { name: Category; description: string }[] = [
  { name: "कविता", description: "भावों और विचारों की मुक्त अभिव्यक्ति" },
  { name: "ग़ज़ल", description: "शेरों में गुँथी हुई गहराई" },
  { name: "शायरी", description: "दो पंक्तियों में समाया एक जहान" },
  { name: "मुक्तक", description: "स्वतंत्र और सम्पूर्ण चार पंक्तियाँ" },
  { name: "प्रेम", description: "प्रेम के अनगिनत रंग" },
  { name: "विरह", description: "बिछड़न की मौन पीड़ा" },
  { name: "समाज", description: "समय और समाज पर चिंतन" },
  { name: "जीवन", description: "जीवन के अनुभव और सीख" },
  { name: "आत्मसंवाद", description: "स्वयं से एक शांत बातचीत" },
];

const AUTHOR = "अरनव त्रिपाठी";

// SAMPLE CONTENT — placeholder poems for layout/demo purposes only.
export const poems: Poem[] = [
  {
    id: "1",
    title: "मैं थक गया हूँ — एक स्वीकारोक्ति",
    slug: "main-thak-gaya-hoon",
    category: "आत्मसंवाद",
    date: "2026-02-18",
    excerpt:
      "[नमूना अंश] यह एक स्वीकारोक्ति है, थकान की, चुप्पी की, और स्वयं से किए गए एक वादे की।",
    content: `[SAMPLE CONTENT — नमूना पंक्तियाँ]

मैं थक गया हूँ, यह कहते हुए भी थकान होती है,
पर चुप रहना अब और संभव नहीं।

हर दिन एक जैसा भार लिए आता है,
और मैं, वही पुराना जवाब लिए खड़ा रहता हूँ।

यह कविता असली नहीं है —
यह केवल एक स्थान भरने के लिए यहाँ है,
जहाँ कभी मेरे असली शब्द होंगे।`,
    tags: ["थकान", "स्वीकारोक्ति", "मौन"],
    featured: true,
    readingTime: "2 मिनट",
    author: AUTHOR,
  },
  {
    id: "2",
    title: "काग़ज़ की उम्र",
    slug: "kagaz-ki-umra",
    category: "कविता",
    date: "2026-02-10",
    excerpt: "[नमूना अंश] हर काग़ज़ की एक उम्र होती है, हर स्याही का एक मौसम।",
    content: `[SAMPLE CONTENT — नमूना पंक्तियाँ]

हर काग़ज़ की एक उम्र होती है,
हर स्याही का अपना एक मौसम।

मैं लिखता हूँ, ताकि कुछ बचा रहे,
उस वक़्त से परे, जो हमेशा भागता रहता है।

(यह पंक्तियाँ प्रतीकात्मक हैं — असली रचना बाद में जोड़ी जाएगी)`,
    tags: ["समय", "स्मृति", "काग़ज़"],
    featured: false,
    readingTime: "1 मिनट",
    author: AUTHOR,
  },
  {
    id: "3",
    title: "तेरे बिना शहर",
    slug: "tere-bina-shahar",
    category: "ग़ज़ल",
    date: "2026-01-28",
    excerpt: "[नमूना अंश] तेरे बिना ये शहर भी अजनबी सा लगता है।",
    content: `[SAMPLE CONTENT — नमूना ग़ज़ल]

तेरे बिना ये शहर भी अजनबी सा लगता है,
हर गली, हर मोड़ अब सिर्फ रास्ता लगता है।

जो कभी अपना था, अब भी अपना है शायद,
पर दिल को अब हर कोई थोड़ा पराया लगता है।

(यह शेर केवल संरचना दिखाने हेतु हैं, वास्तविक ग़ज़ल नहीं)`,
    tags: ["बिछड़न", "शहर", "याद"],
    featured: false,
    readingTime: "2 मिनट",
    author: AUTHOR,
  },
  {
    id: "4",
    title: "दो लफ़्ज़ों की बात",
    slug: "do-lafzon-ki-baat",
    category: "शायरी",
    date: "2026-01-20",
    excerpt: "[नमूना अंश] कभी-कभी दो लफ़्ज़ ही पूरी कहानी कह जाते हैं।",
    content: `[SAMPLE CONTENT]

कुछ बातें अधूरी ही अच्छी लगती हैं,
जैसे तेरा नाम, मेरी हर शाम में।

(नमूना शायरी — वास्तविक रचना नहीं)`,
    tags: ["शायरी", "एहसास"],
    featured: false,
    readingTime: "1 मिनट",
    author: AUTHOR,
  },
  {
    id: "5",
    title: "चार पंक्तियों में जीवन",
    slug: "chaar-panktiyon-mein-jeevan",
    category: "मुक्तक",
    date: "2026-01-12",
    excerpt: "[नमूना अंश] जीवन को चार पंक्तियों में समेटने की एक कोशिश।",
    content: `[SAMPLE CONTENT — नमूना मुक्तक]

जीवन एक किताब है, जिसे हम रोज़ लिखते हैं,
कुछ पन्ने रोते हैं, कुछ पन्ने हँसते हैं।
जो बीत गया उसे थाम के मत बैठो,
आगे के पन्ने अभी कोरे और सादे हैं।`,
    tags: ["जीवन", "मुक्तक"],
    featured: false,
    readingTime: "1 मिनट",
    author: AUTHOR,
  },
  {
    id: "6",
    title: "भीड़ में अकेला",
    slug: "bheed-mein-akela",
    category: "समाज",
    date: "2025-12-30",
    excerpt: "[नमूना अंश] भीड़ के बीच भी अकेलापन कैसे साथ चलता है।",
    content: `[SAMPLE CONTENT]

हर तरफ़ शोर है, फिर भी एक सन्नाटा है,
हर चेहरा जाना-पहचाना, फिर भी अजनबी सा है।

(यह एक प्लेसहोल्डर रचना है)`,
    tags: ["समाज", "अकेलापन"],
    featured: false,
    readingTime: "2 मिनट",
    author: AUTHOR,
  },
  {
    id: "7",
    title: "प्रेम की पहली पंक्ति",
    slug: "prem-ki-pahli-pankti",
    category: "प्रेम",
    date: "2025-12-14",
    excerpt: "[नमूना अंश] कभी प्रेम एक पंक्ति से शुरू होता है, और वहीं ठहर जाता है।",
    content: `[SAMPLE CONTENT — नमूना पंक्तियाँ]

पहली पंक्ति लिखी, फिर मिटा दी,
शायद प्रेम को शब्दों में बाँधना ठीक नहीं।

फिर भी लिखता रहा, मिटाता रहा,
यही तो है, वो अधूरी सी कहानी।`,
    tags: ["प्रेम", "शब्द"],
    featured: false,
    readingTime: "2 मिनट",
    author: AUTHOR,
  },
  {
    id: "8",
    title: "विरह की स्याही",
    slug: "virah-ki-syahi",
    category: "विरह",
    date: "2025-11-22",
    excerpt: "[नमूना अंश] विरह की स्याही से लिखी गई कुछ अधूरी पंक्तियाँ।",
    content: `[SAMPLE CONTENT]

तेरे जाने के बाद, स्याही भी सूखने लगी,
शायद शब्दों को भी तेरी ज़रूरत थी।

(नमूना रचना — प्रतीक्षा है असली शब्दों की)`,
    tags: ["विरह", "स्याही"],
    featured: false,
    readingTime: "1 मिनट",
    author: AUTHOR,
  },
];

// आज की पंक्ति — memorable single lines pulled at random on each visit.
// SAMPLE CONTENT — replace with real standout lines from your work.
export const memorableLines: string[] = [
  "हर काग़ज़ की एक उम्र होती है, हर स्याही का अपना एक मौसम।",
  "जो बीत गया उसे थाम के मत बैठो, आगे के पन्ने अभी कोरे हैं।",
  "शायद प्रेम को शब्दों में बाँधना ठीक नहीं।",
  "तेरे बिना ये शहर भी अजनबी सा लगता है।",
  "कुछ बातें अधूरी ही अच्छी लगती हैं।",
];

export function getAllPoems(): Poem[] {
  return [...poems].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );
}

export function getPoemBySlug(slug: string): Poem | undefined {
  return poems.find((p) => p.slug === slug);
}

export function getFeaturedPoem(): Poem {
  return poems.find((p) => p.featured) ?? poems[0];
}

export function getLatestPoems(count = 3): Poem[] {
  return getAllPoems().slice(0, count);
}

export function getPoemsByCategory(category: Category): Poem[] {
  return getAllPoems().filter((p) => p.category === category);
}

export function getAdjacentPoems(slug: string): {
  prev: Poem | null;
  next: Poem | null;
} {
  const ordered = getAllPoems();
  const index = ordered.findIndex((p) => p.slug === slug);
  return {
    prev: index < ordered.length - 1 ? ordered[index + 1] : null,
    next: index > 0 ? ordered[index - 1] : null,
  };
}

export function getRandomPoem(excludeSlug?: string): Poem {
  const candidates = excludeSlug
    ? poems.filter((p) => p.slug !== excludeSlug)
    : poems;
  return candidates[Math.floor(Math.random() * candidates.length)];
}

export function getAllYears(): number[] {
  const years = new Set(poems.map((p) => new Date(p.date).getFullYear()));
  return Array.from(years).sort((a, b) => b - a);
}

export function formatHindiDate(dateStr: string): string {
  const months = [
    "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
    "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर",
  ];
  const d = new Date(dateStr);
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}
