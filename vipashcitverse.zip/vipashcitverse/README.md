# VipashcitVerse

> जहाँ शब्द सिर्फ लिखे नहीं जाते, जिए जाते हैं।

अरनव त्रिपाठी का निजी हिंदी साहित्यिक संग्रह — कविताएँ, ग़ज़लें, शायरी, मुक्तक और साहित्यिक टिप्पणियाँ।

Personal Hindi poetry archive built with **Next.js 14 (App Router)**, **TypeScript**, and **Tailwind CSS**.

---

## ⚠️ इस कोड में मौजूद कविताएँ असली नहीं हैं

Every poem in `data/poems.ts` is clearly marked **SAMPLE CONTENT**. These are
placeholder verses used only to demonstrate the layout, typography and
reading experience — they are **not** Arnav Tripathi's actual writing.
Replace them with real poems before publishing (see "Adding a new poem" below).

---

## Running the project locally

You need [Node.js](https://nodejs.org) 18.17 or later.

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open http://localhost:3000 in your browser
```

To build for production:

```bash
npm run build
npm run start
```

---

## Project structure

```
vipashcitverse/
├── app/
│   ├── layout.tsx            # Root layout — fonts, header, footer, metadata
│   ├── page.tsx               # Homepage (hero, featured poem, latest, categories)
│   ├── globals.css            # Literary theme, paper texture, dark mode, poem typography
│   ├── about/page.tsx          # मेरे बारे में
│   ├── contact/page.tsx        # संपर्क
│   ├── sangrah/page.tsx        # Full archive (search/filter/sort/grid-list)
│   ├── kavita/page.tsx         # कविताएँ (category-locked archive)
│   ├── gazal/page.tsx          # ग़ज़ल (category-locked archive)
│   ├── shayari/page.tsx        # शायरी (category-locked archive)
│   └── poem/[slug]/page.tsx    # Poetry reader page
├── components/                 # Header, Footer, PoemCard, ArchiveClient, etc.
├── data/
│   └── poems.ts                 # ⭐ Central poetry data — edit this to add your work
├── lib/
│   └── utils.ts                  # Small helpers + notes on adding a real database later
└── tailwind.config.ts            # Parchment/ink/maroon literary color palette
```

---

## Adding a new poem

Open `data/poems.ts` and add a new object to the `poems` array:

```ts
{
  id: "9",
  title: "आपकी कविता का शीर्षक",
  slug: "aapki-kavita-ka-title",       // used in the URL: /poem/aapki-kavita-ka-title
  category: "कविता",                    // one of: कविता, ग़ज़ल, शायरी, मुक्तक, प्रेम, विरह, समाज, जीवन, आत्मसंवाद
  date: "2026-03-01",                   // YYYY-MM-DD
  excerpt: "एक छोटी झलक, दो पंक्तियों में...",
  content: `पहली पंक्ति यहाँ,
दूसरी पंक्ति यहाँ,

नया पैराग्राफ़ यहाँ।`,                  // line breaks are preserved exactly — never auto-justified
  tags: ["टैग1", "टैग2"],
  featured: false,                       // set true to show it in the homepage's "चुनिंदा रचना" section
  readingTime: "2 मिनट",
  author: "अरनव त्रिपाठी",
}
```

That's it — no other file needs to change. The poem will automatically appear
in "नवीन रचनाएँ", the relevant category page, संग्रह, search, and the Random
Poem button.

Set at most one poem's `featured` to `true` at a time (the homepage shows the
first one it finds).

---

## Features included

- Responsive header with desktop nav + mobile hamburger menu, live search
- Literary hero, featured poem section, "नवीन रचनाएँ", category grid
- Dedicated poetry reader page with reading-progress bar, prev/next navigation
- Share, copy, and bookmark actions on every poem (bookmark/theme choice
  persist locally in the visitor's browser via `localStorage`)
- Full archive page (`/sangrah`) with search, category filter, year filter,
  newest/oldest sort, and grid/list toggle
- Category-locked archive pages for कविताएँ / ग़ज़ल / शायरी
- "कोई भी एक कविता" (random poem) button
- "आज की पंक्ति" — a random memorable line shown on the homepage each visit
- Elegant dark mode ("reading at 2 AM") that remembers the visitor's choice
- Hindi-friendly SEO metadata (title, description, Open Graph) on every page
- Client-side search across title, category, tags and full poem text

## What is NOT wired up (by design)

- **The contact form** only shows a confirmation message right now — it does
  not send an email anywhere. To make it work, connect it to a form service
  (e.g. Formspree, Resend) or write a small Next.js API route.
- **Bookmarks and dark-mode preference** are stored in the visitor's own
  browser (`localStorage`), not in a shared database — they won't sync across
  devices.
- **Social links** in the footer/contact page are placeholders (`href="#"`) —
  replace them with your real profile URLs.

## Adding a real database later (optional)

The site currently reads all poems from the local `data/poems.ts` array, so
it works with zero backend setup. When you're ready to manage poems from a
CMS or database (Supabase, Firebase, etc.):

1. Create a new module (e.g. `lib/db.ts`) that fetches poems from your service
   and exposes the same functions as `data/poems.ts` (`getAllPoems`,
   `getPoemBySlug`, `getFeaturedPoem`, `getLatestPoems`,
   `getPoemsByCategory`, `getAdjacentPoems`, `getRandomPoem`).
2. Swap the `@/data/poems` import in the page files under `app/` for your new
   module.

No component or page layout needs to be redesigned — they only depend on the
shape of the `Poem` type, not on where the data comes from.

---

## Tech stack

- [Next.js 14](https://nextjs.org) (App Router)
- [React 18](https://react.dev) + TypeScript
- [Tailwind CSS](https://tailwindcss.com)
- [Lucide React](https://lucide.dev) icons
- Google Fonts — Noto Serif Devanagari (poetry/headings) & Noto Sans Devanagari (UI)

© 2026 Arnav Tripathi.
