"use client";

import { useEffect, useState } from "react";
import { memorableLines } from "@/data/poems";

export default function DailyLine() {
  const [line, setLine] = useState<string | null>(null);

  useEffect(() => {
    setLine(memorableLines[Math.floor(Math.random() * memorableLines.length)]);
  }, []);

  if (!line) return null;

  return (
    <div className="text-center py-10 border-y hairline my-16">
      <p className="text-xs font-sanshi tracking-wide uppercase text-ink/45 dark:text-cream/45">
        आज की पंक्ति
      </p>
      <p className="mt-4 font-serifhi text-xl sm:text-2xl text-ink/85 dark:text-cream/85 max-w-2xl mx-auto px-6">
        “{line}”
      </p>
    </div>
  );
}
