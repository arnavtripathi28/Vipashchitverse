"use client";

import { useState } from "react";

export default function ContactForm() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // NOTE: No backend is wired up yet. This form currently only shows a
    // confirmation message. To make it functional, connect it to a service
    // such as Formspree, an API route, or Supabase — see README.md.
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <p className="text-center font-serifhi text-lg text-ink/80 dark:text-cream/80 py-10">
        धन्यवाद। आपका संदेश प्राप्त हुआ।
      </p>
    );
  }

  const inputClass =
    "w-full bg-transparent border hairline rounded-sm px-4 py-3 text-sm font-sanshi outline-none focus:border-maroon dark:focus:border-maroon-light transition-colors";

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="block text-xs font-sanshi text-ink/55 dark:text-cream/55 mb-2">
          नाम
        </label>
        <input required name="name" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs font-sanshi text-ink/55 dark:text-cream/55 mb-2">
          ईमेल
        </label>
        <input required type="email" name="email" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs font-sanshi text-ink/55 dark:text-cream/55 mb-2">
          संदेश
        </label>
        <textarea required name="message" rows={5} className={inputClass} />
      </div>
      <button
        type="submit"
        className="bg-maroon text-parchment-light dark:bg-maroon-light dark:text-nightpage px-6 py-3 rounded-sm text-sm font-sanshi hover:opacity-90 transition-opacity"
      >
        संदेश भेजें
      </button>
    </form>
  );
}
