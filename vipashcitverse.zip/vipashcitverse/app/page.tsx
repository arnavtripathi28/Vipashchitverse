import Link from "next/link";
import { getFeaturedPoem, getLatestPoems, CATEGORIES } from "@/data/poems";
import PoemCard from "@/components/PoemCard";
import CategoryCard from "@/components/CategoryCard";
import FeaturedPoem from "@/components/FeaturedPoem";
import RandomPoemButton from "@/components/RandomPoemButton";
import DailyLine from "@/components/DailyLine";

export default function HomePage() {
  const featured = getFeaturedPoem();
  const latest = getLatestPoems(3);

  return (
    <>
      {/* Hero */}
      <section className="max-w-4xl mx-auto px-5 sm:px-8 pt-16 sm:pt-24 pb-6 text-center animate-fadeIn">
        <p className="text-xs font-sanshi tracking-widest uppercase text-maroon dark:text-maroon-light">
          व्यक्तिगत साहित्यिक संग्रह
        </p>
        <h1 className="mt-6 font-serifhi text-3xl sm:text-5xl leading-snug sm:leading-snug text-ink dark:text-cream">
          शब्दों में जो रह गया,
          <br />
          वही VipashcitVerse है।
        </h1>
        <p className="mt-6 font-serifhi text-base sm:text-lg text-ink/65 dark:text-cream/65 max-w-xl mx-auto">
          मेरी कविताओं, ग़ज़लों, शायरी और उन भावों का संग्रह जिन्हें काग़ज़ पर
          जगह मिल गई।
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-4">
          <Link
            href="/sangrah"
            className="bg-maroon text-parchment-light dark:bg-maroon-light dark:text-nightpage px-6 py-3 rounded-sm text-sm font-sanshi hover:opacity-90 transition-opacity"
          >
            कविताएँ पढ़ें
          </Link>
          <Link
            href="/about"
            className="border hairline px-6 py-3 rounded-sm text-sm font-sanshi hover:bg-ink/5 dark:hover:bg-cream/10 transition-colors"
          >
            मेरे बारे में
          </Link>
          <RandomPoemButton />
        </div>
      </section>

      <FeaturedPoem poem={featured} />

      {/* नवीन रचनाएँ */}
      <section className="max-w-6xl mx-auto px-5 sm:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-serifhi text-2xl text-ink dark:text-cream">
            नवीन रचनाएँ
          </h2>
          <Link
            href="/sangrah"
            className="text-sm font-sanshi text-maroon dark:text-maroon-light"
          >
            सभी देखें →
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {latest.map((poem) => (
            <PoemCard key={poem.id} poem={poem} />
          ))}
        </div>
      </section>

      <DailyLine />

      {/* कविता संग्रह categories */}
      <section className="max-w-6xl mx-auto px-5 sm:px-8 py-8 pb-24">
        <h2 className="font-serifhi text-2xl text-ink dark:text-cream mb-8">
          कविता संग्रह
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {CATEGORIES.map((c) => (
            <CategoryCard key={c.name} name={c.name} description={c.description} />
          ))}
        </div>
      </section>
    </>
  );
}
