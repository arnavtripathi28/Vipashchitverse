import { notFound } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import {
  getPoemBySlug,
  getAdjacentPoems,
  getAllPoems,
  formatHindiDate,
} from "@/data/poems";
import PoemActions from "@/components/PoemActions";
import ReadingProgress from "@/components/ReadingProgress";
import type { Metadata } from "next";

export function generateStaticParams() {
  return getAllPoems().map((p) => ({ slug: p.slug }));
}

export function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Metadata {
  const poem = getPoemBySlug(params.slug);
  if (!poem) return { title: "रचना नहीं मिली | VipashcitVerse" };
  return {
    title: `${poem.title} | VipashcitVerse`,
    description: poem.excerpt,
    openGraph: {
      title: `${poem.title} | VipashcitVerse`,
      description: poem.excerpt,
      type: "article",
    },
  };
}

export default function PoemPage({ params }: { params: { slug: string } }) {
  const poem = getPoemBySlug(params.slug);
  if (!poem) notFound();

  const { prev, next } = getAdjacentPoems(poem.slug);

  return (
    <>
      <ReadingProgress />
      <article className="max-w-reading mx-auto px-6 py-14 sm:py-20 animate-fadeIn">
        <div className="text-center">
          <p className="text-xs font-sanshi uppercase tracking-widest text-maroon dark:text-maroon-light">
            {poem.category}
          </p>
          <h1 className="mt-4 font-serifhi text-3xl sm:text-4xl text-ink dark:text-cream leading-snug">
            {poem.title}
          </h1>
          <p className="mt-3 text-xs font-sanshi text-ink/50 dark:text-cream/50">
            {formatHindiDate(poem.date)} · {poem.author} · {poem.readingTime}
          </p>
        </div>

        <div className="poem-text mt-12 text-ink/90 dark:text-cream/90">
          {poem.content}
        </div>

        <div className="mt-14 flex items-center justify-center">
          <PoemActions poem={poem} />
        </div>

        {poem.tags.length > 0 && (
          <div className="mt-8 flex flex-wrap justify-center gap-2">
            {poem.tags.map((tag) => (
              <span
                key={tag}
                className="text-xs font-sanshi px-3 py-1 rounded-full border hairline text-ink/55 dark:text-cream/55"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        <nav className="mt-16 pt-8 border-t hairline flex items-center justify-between gap-4">
          {prev ? (
            <Link
              href={`/poem/${prev.slug}`}
              className="flex items-center gap-1 text-sm font-sanshi text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light"
            >
              <ChevronLeft size={15} />
              <span className="truncate max-w-[9rem] sm:max-w-none">
                {prev.title}
              </span>
            </Link>
          ) : (
            <span />
          )}
          {next ? (
            <Link
              href={`/poem/${next.slug}`}
              className="flex items-center gap-1 text-sm font-sanshi text-ink/70 dark:text-cream/70 hover:text-maroon dark:hover:text-maroon-light text-right"
            >
              <span className="truncate max-w-[9rem] sm:max-w-none">
                {next.title}
              </span>
              <ChevronRight size={15} />
            </Link>
          ) : (
            <span />
          )}
        </nav>
      </article>
    </>
  );
}
