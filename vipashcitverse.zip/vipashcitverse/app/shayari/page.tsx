import { getPoemsByCategory } from "@/data/poems";
import ArchiveClient from "@/components/ArchiveClient";

export const metadata = {
  title: "शायरी | VipashcitVerse",
  description: "अरनव त्रिपाठी की शायरी का संग्रह।",
};

export default function ShayariPage() {
  const poems = getPoemsByCategory("शायरी");
  return (
    <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 sm:py-20">
      <h1 className="font-serifhi text-3xl text-ink dark:text-cream mb-2">
        शायरी
      </h1>
      <p className="text-sm font-sanshi text-ink/55 dark:text-cream/55 mb-10">
        दो पंक्तियों में समाया एक जहान।
      </p>
      <ArchiveClient poems={poems} lockedCategory="शायरी" />
    </div>
  );
}
