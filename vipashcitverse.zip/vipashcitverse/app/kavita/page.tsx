import { getPoemsByCategory } from "@/data/poems";
import ArchiveClient from "@/components/ArchiveClient";

export const metadata = {
  title: "कविताएँ | VipashcitVerse",
  description: "अरनव त्रिपाठी की कविताओं का संग्रह।",
};

export default function KavitaPage() {
  const poems = getPoemsByCategory("कविता");
  return (
    <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 sm:py-20">
      <h1 className="font-serifhi text-3xl text-ink dark:text-cream mb-2">
        कविताएँ
      </h1>
      <p className="text-sm font-sanshi text-ink/55 dark:text-cream/55 mb-10">
        भावों और विचारों की मुक्त अभिव्यक्ति।
      </p>
      <ArchiveClient poems={poems} lockedCategory="कविता" />
    </div>
  );
}
