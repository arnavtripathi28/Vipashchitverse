"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { LayoutGrid, List, ArrowRight } from "lucide-react";
import { Poem, Category, CATEGORIES, formatHindiDate } from "@/data/poems";

export default function ArchiveClient({
  poems,
  lockedCategory,
}: {
  poems: Poem[];
  lockedCategory?: Category;
}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>(lockedCategory ?? "सभी");
  const [year, setYear] = useState<string>("सभी");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [view, setView] = useState<"grid" | "list">("grid");

  const years = useMemo(
    () =>
      Array.from(new Set(poems.map((p) => new Date(p.date).getFullYear()))).sort(
        (a, b) => b - a
      ),
    [poems]
  );

  const filtered = useMemo(() => {
    let result = [...poems];

    if (query.trim()) {
      const q = query.trim().toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.content.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    if (category !== "सभी") {
      result = result.filter((p) => p.category === category);
    }

    if (year !== "सभी") {
      result = result.filter(
        (p) => new Date(p.date).getFullYear().toString() === year
      );
    }

    result.sort((a, b) => {
      const diff = new Date(a.date).getTime() - new Date(b.date).getTime();
      return sort === "newest" ? -diff : diff;
    });

    return result;
  }, [poems, query, category, year, sort]);

  const selectClass =
    "bg-transparent border hairline rounded-sm px-3 py-2 text-sm font-sanshi outline-none";

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-8">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="खोजें..."
          className="w-full sm:max-w-xs bg-transparent border hairline rounded-sm px-3 py-2 text-sm font-sanshi outline-none placeholder:text-ink/40 dark:placeholder:text-cream/40"
        />

        <div className="flex flex-wrap gap-3 items-center">
          {!lockedCategory && (
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className={selectClass}
            >
              <option>सभी</option>
              {CATEGORIES.map((c) => (
                <option key={c.name}>{c.name}</option>
              ))}
            </select>
          )}

          <select
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className={selectClass}
          >
            <option>सभी</option>
            {years.map((y) => (
              <option key={y}>{y}</option>
            ))}
          </select>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as "newest" | "oldest")}
            className={selectClass}
          >
            <option value="newest">नवीनतम पहले</option>
            <option value="oldest">पुरानी पहले</option>
          </select>

          <div className="flex border hairline rounded-sm overflow-hidden">
            <button
              onClick={() => setView("grid")}
              aria-label="ग्रिड दृश्य"
              className={`p-2 ${view === "grid" ? "bg-ink/10 dark:bg-cream/10" : ""}`}
            >
              <LayoutGrid size={15} />
            </button>
            <button
              onClick={() => setView("list")}
              aria-label="सूची दृश्य"
              className={`p-2 ${view === "list" ? "bg-ink/10 dark:bg-cream/10" : ""}`}
            >
              <List size={15} />
            </button>
          </div>
        </div>
      </div>

      <p className="text-xs font-sanshi text-ink/45 dark:text-cream/45 mb-6">
        {filtered.length} रचनाएँ मिलीं
      </p>

      {filtered.length === 0 && (
        <p className="text-center py-16 font-serifhi text-ink/50 dark:text-cream/50">
          कोई रचना नहीं मिली।
        </p>
      )}

      {view === "grid" ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((poem) => (
            <Link
              key={poem.id}
              href={`/poem/${poem.slug}`}
              className="paper-card p-5 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300"
            >
              <p className="text-xs font-sanshi uppercase tracking-wide text-maroon dark:text-maroon-light">
                {poem.category}
              </p>
              <h3 className="mt-2 font-serifhi text-lg">{poem.title}</h3>
              <p className="mt-2 text-sm font-serifhi text-ink/60 dark:text-cream/60 line-clamp-2">
                {poem.excerpt}
              </p>
              <p className="mt-4 text-xs font-sanshi text-ink/40 dark:text-cream/40">
                {formatHindiDate(poem.date)}
              </p>
            </Link>
          ))}
        </div>
      ) : (
        <div className="flex flex-col divide-y hairline border-t border-b hairline">
          {filtered.map((poem) => (
            <Link
              key={poem.id}
              href={`/poem/${poem.slug}`}
              className="group flex items-center justify-between py-4 hover:bg-ink/5 dark:hover:bg-cream/5 px-2 transition-colors"
            >
              <div>
                <p className="font-serifhi text-base">{poem.title}</p>
                <p className="text-xs font-sanshi text-ink/45 dark:text-cream/45 mt-1">
                  {poem.category} · {formatHindiDate(poem.date)}
                </p>
              </div>
              <ArrowRight
                size={15}
                className="text-maroon dark:text-maroon-light opacity-0 group-hover:opacity-100 transition-opacity"
              />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
