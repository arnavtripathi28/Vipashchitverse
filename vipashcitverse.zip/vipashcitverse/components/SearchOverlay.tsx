"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, X } from "lucide-react";
import { getAllPoems, formatHindiDate } from "@/data/poems";

export default function SearchOverlay({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [query, setQuery] = useState("");
  const poems = getAllPoems();

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.trim().toLowerCase();
    return poems.filter((p) => {
      return (
        p.title.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.content.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q))
      );
    });
  }, [query, poems]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-ink/40 dark:bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="max-w-xl mx-auto mt-24 mx-4 sm:mx-auto">
        <div className="bg-parchment-light dark:bg-nightpage-card border hairline rounded-sm shadow-xl">
          <div className="flex items-center gap-3 px-4 py-3 border-b hairline">
            <Search size={18} className="text-ink/50 dark:text-cream/50" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="शीर्षक, श्रेणी या शब्द खोजें..."
              className="flex-1 bg-transparent outline-none font-sanshi text-sm placeholder:text-ink/40 dark:placeholder:text-cream/40"
            />
            <button
              onClick={onClose}
              aria-label="बंद करें"
              className="text-ink/50 dark:text-cream/50 hover:text-ink dark:hover:text-cream"
            >
              <X size={18} />
            </button>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {query.trim() && results.length === 0 && (
              <p className="px-4 py-6 text-sm text-ink/50 dark:text-cream/50 font-sanshi">
                कोई रचना नहीं मिली।
              </p>
            )}
            {results.map((poem) => (
              <Link
                key={poem.id}
                href={`/poem/${poem.slug}`}
                onClick={onClose}
                className="block px-4 py-3 border-b hairline last:border-0 hover:bg-ink/5 dark:hover:bg-cream/5 transition-colors"
              >
                <p className="font-serifhi text-base">{poem.title}</p>
                <p className="text-xs text-ink/50 dark:text-cream/50 font-sanshi mt-1">
                  {poem.category} · {formatHindiDate(poem.date)}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
