"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, Search, X } from "lucide-react";
import DarkModeToggle from "./DarkModeToggle";
import SearchOverlay from "./SearchOverlay";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/kavita", label: "कविताएँ" },
  { href: "/gazal", label: "ग़ज़ल" },
  { href: "/shayari", label: "शायरी" },
  { href: "/sangrah", label: "संग्रह" },
  { href: "/about", label: "मेरे बारे में" },
  { href: "/contact", label: "संपर्क" },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-parchment/90 dark:bg-nightpage/90 backdrop-blur border-b hairline">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <Link
          href="/"
          className="font-serifhi text-lg sm:text-xl tracking-wide text-maroon dark:text-maroon-light"
        >
          VIPASHCITVERSE
        </Link>

        <nav className="hidden md:flex items-center gap-7 font-sanshi text-sm">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-ink/75 dark:text-cream/75 hover:text-maroon dark:hover:text-maroon-light transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSearchOpen(true)}
            aria-label="खोजें"
            className="w-9 h-9 flex items-center justify-center rounded-full border hairline hover:bg-ink/5 dark:hover:bg-cream/10 transition-colors"
          >
            <Search size={16} />
          </button>
          <DarkModeToggle />
          <button
            onClick={() => setMenuOpen(true)}
            aria-label="मेन्यू खोलें"
            className="md:hidden w-9 h-9 flex items-center justify-center rounded-full border hairline"
          >
            <Menu size={18} />
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-parchment dark:bg-nightpage animate-fadeIn">
          <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between border-b hairline">
            <span className="font-serifhi text-lg text-maroon dark:text-maroon-light">
              VIPASHCITVERSE
            </span>
            <button
              onClick={() => setMenuOpen(false)}
              aria-label="बंद करें"
              className="w-9 h-9 flex items-center justify-center rounded-full border hairline"
            >
              <X size={18} />
            </button>
          </div>
          <nav className="flex flex-col px-6 py-8 gap-6 font-sanshi text-lg">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-ink/85 dark:text-cream/85 border-b hairline pb-4"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
    </header>
  );
}
