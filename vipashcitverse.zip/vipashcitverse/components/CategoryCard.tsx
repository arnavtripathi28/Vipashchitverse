import Link from "next/link";
import { Category } from "@/data/poems";

const CATEGORY_ROUTES: Partial<Record<Category, string>> = {
  "कविता": "/kavita",
  "ग़ज़ल": "/gazal",
  "शायरी": "/shayari",
};

export default function CategoryCard({
  name,
  description,
}: {
  name: Category;
  description: string;
}) {
  const href = CATEGORY_ROUTES[name] ?? `/sangrah?category=${encodeURIComponent(name)}`;
  return (
    <Link
      href={href}
      className="paper-card p-6 flex flex-col justify-between h-32 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300"
    >
      <h3 className="font-serifhi text-lg text-ink dark:text-cream">{name}</h3>
      <p className="text-xs font-sanshi text-ink/55 dark:text-cream/55">
        {description}
      </p>
    </Link>
  );
}
